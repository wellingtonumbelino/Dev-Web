import React from 'react';
import ReactDOM from 'react-dom';

import Imc from './components/Imc';

const root = document.getElementById('root');

ReactDOM.render(<Imc />, root);